# functions

def hello():
    print("hello")

def beautiful_day(text):
    return "Hello "+text+". It is a beautiful day!"

# "print" is not "return" !

hello()
#beautiful_day("Goodbye")

x = beautiful_day("Franek")
print(x)