import my_library


my_library.hello()
x = my_library.beautiful_day("Thomas")
print(x)