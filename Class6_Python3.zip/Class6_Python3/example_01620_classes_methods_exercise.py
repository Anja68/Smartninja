# Read the 2 exercises.
#
# Part 1)
# add 2 methods to the class Car:
# a) decrease energy, this method decreases the battery status by 1
# b) increase energy, this method increases the battery status by 1
# Part 2)
# create an instance of Car
# demonstrate the functioning of the methods
# by always printing the battery status after applying the methods


class Car(object):
    def __init__(self):
        self.battery_status = 0

    def increase_battery(self):
        if self.battery_status<100:
            self.battery_status += 1
        else:
            print("Battery is Full")

    def decrease_battery(self):
        if self.battery_status>0:
            self.battery_status -= 1
        else:
            print("Battery is Empty")


my_car = Car()
my_car.decrease_battery()
print(my_car.battery_status)
my_car.increase_battery()
print(my_car.battery_status)

my_car.decrease_battery()
print(my_car.battery_status)


class Hero(object):
    def __init__(self, name):
        self.experience = 0
        self.name = name

thor = Hero("Thor")
print(thor.experience)
print(thor.name)