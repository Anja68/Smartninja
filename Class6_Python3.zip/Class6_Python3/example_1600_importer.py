import example_01610_classes_instances

a = example_01610_classes_instances.Human(12, "hallo")