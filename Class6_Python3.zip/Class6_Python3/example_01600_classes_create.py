class Human(object):
    def __init__(self, age, name):
        self.age = age
        self.name = name
