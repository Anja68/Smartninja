# create a class bank account
# it has 2 fields: name and balance
# it has methods to withdraw and deposit and print statement
