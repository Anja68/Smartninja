import my_library2

my_library2.hello()