import example_01001_main_exercise_solution

x = example_01001_main_exercise_solution.add_10(25)
print(x)