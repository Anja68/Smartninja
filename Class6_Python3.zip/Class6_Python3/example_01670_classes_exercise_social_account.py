# create classes for social account
# they have a field for: name, friends
# they have methods to: count_friends, befriend, unfriend
