def hello():
    print("hello")

def beautiful_day(text):
    return "Hello "+text+". It is a beautiful day!"