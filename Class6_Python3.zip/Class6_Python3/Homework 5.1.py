def numbers_sum(num1, num2):
    result = num1 + num2
    return result


print(numbers_sum(5, 23))
print(numbers_sum(1, 1))
print(numbers_sum(225, 175))
print(numbers_sum(5000, 23000))