# create a dictionary which stores the following values
# your first name
# your surname
# your eye colour
# then print the dictionary in the terminal

Franek = {"First Name":"Franciszek", "Surname":"Bartnik", "Eye Colour":"green"}

print(Franek)

# Then add the following element
# "Python" : "Professional"
# and print the dictionary in the terminal again

Franek["Python"]="Professional"

print(Franek)
