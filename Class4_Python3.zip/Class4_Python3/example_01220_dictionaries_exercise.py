# create a dictionary which stores the following values
# your first name
# your surname
# your eye colour
# then print the dictionary in the terminal



# Then add the following element
# "Python" : "Professional"
# and print the dictionary in the terminal again