# new type!

#              0        1        2
# a_list = ["salad", "mango", "banana"]
# a_list[1]

# a_dict = {"name": "Theda", "age": 23, "occupation": "pianist"}
# a_dict["name"]


# DICTIONARY
# dictionaries are similar to lists
# however, they are not ordered
# and each item has a reference key

dict ={'Name': 'Zara', 'Age': 7, 'Class': 'First'}
print("Name: ", dict['Name'])
print("Age: ", dict['Age'])

# changing an element

dict["Name"]="Sarah"
print(dict)

# adding an element

dict["Second Name"] = "Maria"
print(dict)