import datetime

# we now want to incorporate the time of the high score
# into the high score list
# for this we need the datetime library

current_time = datetime.datetime.now()

print(current_time)