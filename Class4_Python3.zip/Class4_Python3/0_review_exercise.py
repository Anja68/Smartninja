# read the data in the file hello.txt
# and print it in the terminal