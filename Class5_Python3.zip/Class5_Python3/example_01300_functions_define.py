def hello():
    print("Hi, this is Smartninja")

hello()
hello()
