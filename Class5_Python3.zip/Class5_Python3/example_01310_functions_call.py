
def func():
    return "Hi, this is main"


greeting = func()
print(greeting)
