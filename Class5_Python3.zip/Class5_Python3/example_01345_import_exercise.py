# create a new file called "my_library.py"
# write the functions from the previous exercise in that library

# import the file "my_library.py"
# use one of the functions and print it's result