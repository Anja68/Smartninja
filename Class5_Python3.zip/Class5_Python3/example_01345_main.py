import even2

print even2.even(5)