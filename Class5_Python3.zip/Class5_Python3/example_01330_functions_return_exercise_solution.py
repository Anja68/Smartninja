# Create a function called say_hi
# the function takes no arguments
# the function always returns "hi"
# call the function and save its result in a variable called: greeting
# print greeting

def say_hi():
    return "hi"

greeting = say_hi()

print(greeting)

# create a function called echo
# it has 1 argument called text
# the function returns the text twice (hi -> hihi)
# call the function and print its result for an example

def echo(text):
    return text+text

print(echo("echo "))

