a_list=[1,"two",3,4,5.0,10,110,1100]
print(a_list)
dict={1:1,2:2,3:3}
print(dict)
