
def print_greeting(name,x):
    print("Hello " + name)
    x+=10
    return x

output= print_greeting("Dude", 10)
output2=print_greeting("Franek",20)

print(output)
print(output2)
