def say_hi():
    return "hi"

def echo(text):
    return text+text
