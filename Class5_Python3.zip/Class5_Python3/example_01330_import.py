import my_library

print(my_library.echo("hello"))