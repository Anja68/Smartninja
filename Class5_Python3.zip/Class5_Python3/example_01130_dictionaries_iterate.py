capitals = {"France": "Paris",
            "Iceland": "Reykjavik",
            "Denmark": "Copenhagen",
            "Litauen": "Vilnius",
            "Canada": "Ottawa",
            "Austria": "Wien"}

for i in capitals: # iterates over keys
    print(i, capitals[i])
