def adder(a, b):
    result = a + b
    return result


my_sum = adder(1, 14)
print(my_sum)
print(adder(1,20))
