# open the file "height.txt"
# it contains the height of each person in the class
# save its content as a list
# find out what the average height is