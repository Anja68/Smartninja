# use the list: particles = ["protons", "neutronen", "elektronen"]
# open a file and write the elements of the list seperated by a comma into the file
