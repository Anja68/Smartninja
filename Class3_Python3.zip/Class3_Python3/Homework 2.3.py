a = "HELLO"
b = a.lower()
c = "what's up?"
d = c.upper()

print("lowercase:",b,", and uppercase:",d )
